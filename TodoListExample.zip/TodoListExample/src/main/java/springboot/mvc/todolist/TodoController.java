package springboot.mvc.todolist;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("name")
public class TodoController {
	
	@Autowired
	private TodoService service;
	
	@RequestMapping(method = RequestMethod.GET,value = "/todo-list")
	public String todoList(ModelMap model) {
		model.put("todoItems", service.getTodolist());
		return "todo-list";
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "/add-todo")
	public String addNewTodoPage() {
		return "add-todo";
	}
	
	@RequestMapping(method = RequestMethod.POST,value = "/add-todo")
	public String addNewTodo(@RequestParam String desc, @RequestParam String isDone,ModelMap model) {
		
		Todo todo = new Todo(desc, Boolean.valueOf(isDone));
		service.addTodo(todo);
		return "redirect:/todo-list";
	}
	
	
	

}
