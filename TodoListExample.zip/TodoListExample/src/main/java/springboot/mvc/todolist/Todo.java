package springboot.mvc.todolist;

public class Todo {

	private String desc;
	private boolean isDone;
	public Todo(String desc, boolean isDone) {
		this.desc = desc;
		this.isDone = isDone;
	}
	public String getDesc() {
		return desc;
	}
	public boolean getIsDone() {
		return isDone;
	}
	
	
	
	
}
