package springboot.mvc.todolist;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class TodoService {
	
	private static List<Todo> todolist = new ArrayList<>();
	
	static {
		todolist.add(new Todo("Credit Card Paymnt", false));
		todolist.add(new Todo("bill payment", false));
		
	}

	public List<Todo> getTodolist() {
		return todolist;
	}
	
	public boolean addTodo(Todo todo) {
		return todolist.add(todo);
	}

}
