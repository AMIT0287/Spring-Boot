package springboot.mvc.data.jpa;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@RequestMapping(value = "emp/controller/getDetails", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<EmployeeBean>> getEmployeeDetails() {
		List<EmployeeBean> listEmployee = employeeService.getEmployeeDetails();
		return new ResponseEntity<List<EmployeeBean>>(listEmployee, HttpStatus.OK);
	}

	@RequestMapping(value = "emp/controller/getDetailsById/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<EmployeeBean> getEmployeeDetailByEmployeeId(@PathVariable("id") int myId) {
		EmployeeBean employee = employeeService.getEmployeeDetailByEmployeeId(myId);

		if (employee != null) {
			return new ResponseEntity<EmployeeBean>(employee, HttpStatus.OK);
		} else {
			return new ResponseEntity<EmployeeBean>(HttpStatus.NOT_FOUND);
		}
	}

	@RequestMapping(value = "/emp/controller/addEmp", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.TEXT_HTML_VALUE)
	public ResponseEntity<String> addEmployee(@RequestBody EmployeeBean employee) {
		int id = employeeService.addEmployee(employee);
		return new ResponseEntity<String>("Employee added successfully with id:" + id, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/emp/controller/updateEmp", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<EmployeeBean> updateEmployee(@RequestBody EmployeeBean employee) {
		EmployeeBean employee2 = employeeService.updateEmployee(employee);
		if (employee2 == null) {
			return new ResponseEntity<EmployeeBean>(employee2, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<EmployeeBean>(employee2, HttpStatus.OK);
	}

	@RequestMapping(value = "/emp/controller/deleteEmp/{id}", method = RequestMethod.DELETE,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<EmployeeBean> deleteEmployee(@PathVariable("id") int myId) {
		EmployeeBean employee = employeeService.deleteEmployee(myId);
		if (employee == null) {
			return new ResponseEntity<EmployeeBean>(employee, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<EmployeeBean>(employee, HttpStatus.OK);
	}
	
	// http://localhost:8090/emp/controller/getDetailsSalary/20000
		@RequestMapping(value = "emp/controller/getDetailsSalary/{sal}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<List<EmployeeBean>> getAllEmployeesBySalary(@PathVariable("sal") Double salary) {
			List<EmployeeBean> listEmployee = employeeService.getAllEmployeesBySalary(salary);
			System.out.println(listEmployee);
			return new ResponseEntity<List<EmployeeBean>>(listEmployee, HttpStatus.OK);
		}
		
		// http://localhost:8090/emp/controller/getEmployeeCountDept
		@RequestMapping(value = "emp/controller/getEmployeeCountDept", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<List<Object>> getDeptCodesAndCountOfEmployee() {
			List<Object> listEmployee = employeeService.getDeptCodesAndCountOfEmployee();
			System.out.println(listEmployee);
			return new ResponseEntity<List<Object>>(listEmployee, HttpStatus.OK);
		}
}
