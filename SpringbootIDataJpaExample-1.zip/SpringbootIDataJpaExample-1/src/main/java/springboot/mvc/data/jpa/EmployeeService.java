package springboot.mvc.data.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeDAO;
	
	public int addEmployee(EmployeeBean employee) {

		EmployeeEntity employeeEntity = new EmployeeEntity();
		BeanUtils.copyProperties(employee, employeeEntity);
		EmployeeEntity emp= (EmployeeEntity)employeeDAO.save(employeeEntity);
		return emp.getEmployeeId();
	}

	public List<EmployeeBean> getEmployeeDetails(){
		List<EmployeeEntity> collec =employeeDAO.findAll();
		List<EmployeeBean> listEmployee = new ArrayList<EmployeeBean> ();
		for (EmployeeEntity employeeEntity : collec) {
			EmployeeBean employee=new EmployeeBean();
			BeanUtils.copyProperties(employeeEntity, employee);
			listEmployee.add(employee);
		}
		return listEmployee;
	}
	
	public EmployeeBean getEmployeeDetailByEmployeeId(int employeeId){
		EmployeeBean employee =null;
		Optional<EmployeeEntity> employeeEntity= employeeDAO.findById(employeeId);
		if(employeeEntity!=null && employeeEntity.isPresent()){
			employee= new EmployeeBean();
			BeanUtils.copyProperties(employeeEntity.get(), employee);
		}
		return employee;
	}
	public EmployeeBean deleteEmployee(int employeeId){
		EmployeeBean employee =null;
		Optional<EmployeeEntity> employeeEntity= employeeDAO.findById(employeeId);
		if(employeeEntity!=null && employeeEntity.isPresent()){
			employeeDAO.delete(employeeEntity.get());
			employee= new EmployeeBean();
			BeanUtils.copyProperties(employeeEntity, employee);
		}
		return employee;
	}
	
	public EmployeeBean updateEmployee(EmployeeBean employee){
		EmployeeBean employee2 =null;
		Optional<EmployeeEntity> employeeEntity= employeeDAO.findById(employee.getEmployeeId());
		if(employeeEntity!=null){
			//update operation
			BeanUtils.copyProperties(employee, employeeEntity);	
			employeeDAO.save(employeeEntity.get());
			
			//copying the properties back to EmployeeDTO Object 
			employee2= new EmployeeBean();
			BeanUtils.copyProperties(employeeEntity, employee2);
		}
		return employee2;
	}
	
	public List<EmployeeBean> getAllEmployeesBySalary(Double salary){
		List<EmployeeEntity> listEmployee= employeeDAO.getAllEmployeesBySalary(salary);
		List<EmployeeBean> listEmployeeDTO = new ArrayList<EmployeeBean>();
		
		for (EmployeeEntity employeeEntity : listEmployee) {
			 EmployeeBean employee2 = new EmployeeBean();
			 BeanUtils.copyProperties(employeeEntity, employee2);
			 listEmployeeDTO.add(employee2);
		}
		return listEmployeeDTO;
	}
	
	public List<Object> getDeptCodesAndCountOfEmployee(){
		List<Object> listEmployee= employeeDAO.getDeptCodesAndCountOfEmployee();
		return listEmployee;
	}

}
