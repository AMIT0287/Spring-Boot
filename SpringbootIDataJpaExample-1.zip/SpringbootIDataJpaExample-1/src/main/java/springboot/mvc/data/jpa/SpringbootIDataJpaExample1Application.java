package springboot.mvc.data.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootIDataJpaExample1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootIDataJpaExample1Application.class, args);
	}

}
