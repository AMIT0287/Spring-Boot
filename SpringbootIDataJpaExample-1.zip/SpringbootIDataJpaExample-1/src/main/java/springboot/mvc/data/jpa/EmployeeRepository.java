package springboot.mvc.data.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EmployeeRepository extends JpaRepository<EmployeeEntity, Integer> {
	
	
	@Query("select k from EmployeeEntity k where k.salary>=?1")
	List<EmployeeEntity> getAllEmployeesBySalary(Double salary);
	
	@Query(name = "EmployeeDAO.getDeptCodesAndCountOfEmployee")
	List<Object> getDeptCodesAndCountOfEmployee();

}
