
INSERT INTO employee (employee_id, employee_name,department_code, salary) VALUES (1005, 'MSD'   ,101 , 100000);
INSERT INTO employee (employee_id, employee_name,department_code, salary) VALUES (1006, 'JAG'   ,102 , 100000);
INSERT INTO employee (employee_id, employee_name,department_code, salary) VALUES (1007, 'MSK'   ,103 , 100000);

COMMIT;