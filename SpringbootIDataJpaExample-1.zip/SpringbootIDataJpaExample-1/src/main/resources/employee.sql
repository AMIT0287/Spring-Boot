DROP DATABASE IF EXISTS springbootdb;
CREATE DATABASE springbootdb; 
USE springbootdb;

DROP TABLE IF EXISTS employee;
CREATE TABLE IF NOT EXISTS employee (
  employee_id int(11) unsigned NOT NULL AUTO_INCREMENT,
  employee_name varchar(20) DEFAULT NULL,
  salary double DEFAULT NULL,
  department_code int(11),
  PRIMARY KEY (employeeId)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

commit;
