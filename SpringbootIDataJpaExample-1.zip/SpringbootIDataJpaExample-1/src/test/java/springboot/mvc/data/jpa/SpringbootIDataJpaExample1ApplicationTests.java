package springboot.mvc.data.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootIDataJpaExample1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
