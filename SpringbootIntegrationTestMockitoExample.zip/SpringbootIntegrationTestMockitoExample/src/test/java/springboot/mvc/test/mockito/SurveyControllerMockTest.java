package springboot.mvc.test.mockito;

import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = SurveyController.class)
class SurveyControllerMockTest {
	
	@MockBean
	private SurveyService service;
	
	@Autowired
	private MockMvc mockMvc;
	
	

	@Test
	void test() throws Exception {
		
		Question q1 = new Question("id1", "IPL 2020 winnner", "MI", Arrays.asList("CSK,KKR,MI"));
		
		when(service.retrieveQuestion(Mockito.anyString(), Mockito.anyString())).thenReturn(q1);
		
		RequestBuilder requilder =  MockMvcRequestBuilders.get("/surveys/survey1/questions/question1").accept(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requilder).andReturn();
		
		String expected = "{\"id\":\"id1\",\"description\":\"IPL 2020 winnner\"}";
		
		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(),false);
		
		
		//fail("Not yet implemented");
	}

}
