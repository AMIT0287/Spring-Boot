package springboot.mvc.test.mockito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootIntegrationTestMockitoExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
