package springboot.mvc.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

public class MockTestexample {
	
	
	@Test
	public void test() {
		DataService dataServiceMock = mock(DataService.class);
		when(dataServiceMock.retrieveAllData()).thenReturn(new int[] {12,14,7});
		
		DataBusinessImpl bus = new DataBusinessImpl(dataServiceMock);
		int result = bus.findGreatest();
		assertEquals(14, result);
	}

}
