package springboot.mvc.Mockito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockitoExample1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
