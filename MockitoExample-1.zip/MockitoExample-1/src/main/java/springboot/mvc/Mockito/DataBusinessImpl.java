package springboot.mvc.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DataBusinessImpl {
	
	DataBusinessImpl(DataService service){
		this.service=service;
	}
	
	@Autowired
	private DataService service;
	
	public int findGreatest() {
		int[] data = service.retrieveAllData();
		
		int greatest = Integer.MIN_VALUE;
		
		for (int i = 0; i < data.length; i++) {
			if(data[i]>greatest) {
				greatest=data[i];
			}
			
		}
		
		return greatest;
	}

}
