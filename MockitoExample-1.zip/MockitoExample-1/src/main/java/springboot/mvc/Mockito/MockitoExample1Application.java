package springboot.mvc.Mockito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockitoExample1Application {

	public static void main(String[] args) {
		SpringApplication.run(MockitoExample1Application.class, args);
	}

}
