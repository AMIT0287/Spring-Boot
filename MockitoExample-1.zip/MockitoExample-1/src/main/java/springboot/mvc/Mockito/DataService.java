package springboot.mvc.Mockito;

public interface DataService {
	
	public int[] retrieveAllData();

}
