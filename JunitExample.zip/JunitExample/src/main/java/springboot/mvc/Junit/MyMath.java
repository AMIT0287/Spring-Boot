package springboot.mvc.Junit;

public class MyMath {
	
	
	public int addNumber(int a,int b) {
		return a+b;
	}

}
