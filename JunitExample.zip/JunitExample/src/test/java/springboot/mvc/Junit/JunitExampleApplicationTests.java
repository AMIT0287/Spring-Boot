package springboot.mvc.Junit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunitExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
