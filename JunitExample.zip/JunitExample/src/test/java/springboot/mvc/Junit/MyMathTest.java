package springboot.mvc.Junit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MyMathTest {
	
	
	@BeforeAll
	public static void beforeClassTest() {
		System.out.println("BeforeTestClass");
	}
	
	@AfterAll
	public static void afterClassTest() {
		System.out.println("AfterTestClass");
	}
	
	@BeforeEach
	public void beforeTest() {
		System.out.println("beforeTest");
	}
	
	@AfterEach
	public void aferTest() {
		System.out.println("AfterEach");
	}
	
	@Test
	public void test() {
		
		MyMath match = new MyMath();
		assertEquals(12, match.addNumber(5, 7));
		//assertEquals(12, match.addNumber(5, 2));
		
	}
	

	@Test
	public void test1() {
		
		MyMath match = new MyMath();
		//assertEquals(12, match.addNumber(5, 7));
		assertEquals(12, match.addNumber(5, 2));
		
	}

}
