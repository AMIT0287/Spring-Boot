package springboot.mvc.actuator.metrics.counter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCustomMetricCounterActuatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
