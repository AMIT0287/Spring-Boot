package springboot.mvc.todo.actuator.custom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCustomActuatorExample11Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCustomActuatorExample11Application.class, args);
	}

}
