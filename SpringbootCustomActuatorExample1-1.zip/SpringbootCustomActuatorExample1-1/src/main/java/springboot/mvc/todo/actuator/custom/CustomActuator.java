package springboot.mvc.todo.actuator.custom;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.stereotype.Component;

@Endpoint(enableByDefault = true,id = "db-info")
@Component
public class CustomActuator {
	
	@ReadOperation
	public String db_version() {
		return "latest_12.4";
	}

}
