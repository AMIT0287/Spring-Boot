package springboot.mvc.todo.actuator.custom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCustomActuatorExample11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
