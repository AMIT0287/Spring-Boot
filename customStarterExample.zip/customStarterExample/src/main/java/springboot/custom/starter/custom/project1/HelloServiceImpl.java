package springboot.custom.starter.custom.project1;

public class HelloServiceImpl implements HelloService{
	
	@Override
	public void sayHello() {
		System.out.println("HelloServiceImpl constructor called..");
		
	}

}
