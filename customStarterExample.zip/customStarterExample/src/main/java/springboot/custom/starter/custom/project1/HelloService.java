package springboot.custom.starter.custom.project1;

public interface HelloService {
	
	public void sayHello();

}
