package springboot.mvc.todo.actuator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootActuatorExample1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootActuatorExample1Application.class, args);
	}

}
