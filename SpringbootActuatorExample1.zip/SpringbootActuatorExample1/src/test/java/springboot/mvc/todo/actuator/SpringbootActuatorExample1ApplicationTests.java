package springboot.mvc.todo.actuator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootActuatorExample1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
