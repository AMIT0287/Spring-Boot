package springboot.mvc.security.basic;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;
import org.springframework.web.filter.OncePerRequestFilter;

@Component("customFilter")
public class CustomFilter extends OncePerRequestFilter {
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private UserDetailsService userDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String basicAuthKey = request.getHeader("Authorization");

		String userNameAndPassordEncoded = basicAuthKey.substring(6);

		String decodedUsernameAndPassword = new String(Base64Utils.decode(userNameAndPassordEncoded.getBytes()));
		
		String username = decodedUsernameAndPassword.split(":")[0];
		String password = decodedUsernameAndPassword.split(":")[1];
		
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			byte[] sha256EncryptedPasword = md.digest(password.getBytes("UTF-8"));
			
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
			
			UserDetails ud = userDetailsService.loadUserByUsername(username);
			
			if(ud.getUsername().equalsIgnoreCase(username) && ud.getPassword().equalsIgnoreCase(password)) {
				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
						ud, null, ud.getAuthorities());
				
				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
			}
			
			filterChain.doFilter(request, response);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

}
