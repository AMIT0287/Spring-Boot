package springboot.custom.starter.custom.project2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomStarterExample2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
