package springboot.custom.starter.custom.project2;

import springboot.custom.starter.custom.project1.HelloService;

public class CustomHelloService implements HelloService {

	@Override
	public void sayHello() {
		System.out.println("CustomHelloService constructor called... ");
		
	}

}
