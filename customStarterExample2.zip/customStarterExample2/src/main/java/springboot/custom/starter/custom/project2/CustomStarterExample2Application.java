package springboot.custom.starter.custom.project2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import springboot.custom.starter.custom.project1.HelloService;

@SpringBootApplication
public class CustomStarterExample2Application implements CommandLineRunner {
	
	@Autowired
	private HelloService service;

	public static void main(String[] args) {
		SpringApplication.run(CustomStarterExample2Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		service.sayHello();
		
	}
	
	@Bean
	public HelloService getHelloService() {
		return new CustomHelloService();
	}

}
