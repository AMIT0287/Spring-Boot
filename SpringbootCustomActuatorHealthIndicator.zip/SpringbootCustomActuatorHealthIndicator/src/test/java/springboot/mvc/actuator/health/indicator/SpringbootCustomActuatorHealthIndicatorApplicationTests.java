package springboot.mvc.actuator.health.indicator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCustomActuatorHealthIndicatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
