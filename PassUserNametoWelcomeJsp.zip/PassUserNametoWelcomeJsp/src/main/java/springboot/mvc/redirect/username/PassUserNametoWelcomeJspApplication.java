package springboot.mvc.redirect.username;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PassUserNametoWelcomeJspApplication {

	public static void main(String[] args) {
		SpringApplication.run(PassUserNametoWelcomeJspApplication.class, args);
	}

}
