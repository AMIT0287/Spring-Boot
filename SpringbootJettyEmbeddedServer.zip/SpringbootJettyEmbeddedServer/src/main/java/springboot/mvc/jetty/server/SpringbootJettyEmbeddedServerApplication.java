package springboot.mvc.jetty.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJettyEmbeddedServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJettyEmbeddedServerApplication.class, args);
	}

}
