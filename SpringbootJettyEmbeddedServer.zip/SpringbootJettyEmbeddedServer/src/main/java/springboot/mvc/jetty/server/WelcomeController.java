package springboot.mvc.jetty.server;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeController {
	
	@RequestMapping(method = RequestMethod.GET, value = "/wecome/")
	public String welcome() {
		return "Welcome to spring boot Jetty server";
		
	}

}
